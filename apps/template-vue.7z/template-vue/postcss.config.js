const path = require('path');

module.exports = {
  plugins: {
    autoprefixer: {},
  },
};
