<template>
  <div>Target work</div>
</template>
