import { Component } from '@angular/core';

@Component({
  selector: 'app-tempalte',
  template: `<h1>Template Angular Work</h1>`,
})
export class TemplateComponent {}
